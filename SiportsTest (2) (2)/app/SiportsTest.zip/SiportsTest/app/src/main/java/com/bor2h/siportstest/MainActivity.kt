package com.bor2h.siportstest

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.bor2h.siportstest.databinding.ActivityMainBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class MainActivity : AppCompatActivity() {
    // 전역으로 사용할 Firebase Auth를 만들어 준다
    private lateinit var auth : FirebaseAuth

    // 뷰 바인딩
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // 파이어베이스 Authentication
        auth = Firebase.auth

        // 뷰 바인딩
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        // 인텐트
        val intentJoin = Intent(this, JoinActivity::class.java)

        binding.btnJoin.setOnClickListener {
            startActivity(intentJoin)
        }

        initLoginButton()
    }

    // 로그인
    private fun initLoginButton() {
        binding.btnLogin.setOnClickListener {
            val email = binding.textFieldEmail.text.toString()
            val password = binding.textFieldPassword.text.toString()

            auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener { task ->
                    if(task.isSuccessful) {
                        Toast.makeText(this,"로그인에 성공했습니다!",Toast.LENGTH_SHORT).show()
                        // 액티비티 종료
                        finish()
                    } else {
                        Toast.makeText(this,"아이디와 비밀번호를 확인해주세요.",Toast.LENGTH_SHORT).show()
                    }
                }
        }
    }
}